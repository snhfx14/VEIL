using UnityEngine;

namespace AulaFSM
{
    /// <summary>
    /// Definição de um nível. O mapa é desenhado em texto (cada carácter = 2x2 metros):
    ///   .  chão        #  caixa       B  caixa grande empilhada
    ///   P  jogador     E  guarda      G  diamante
    /// </summary>
    public class LevelData
    {
        public string Name;
        public string[] Map;
        public float GuardViewDistance = 9f;
        public float GuardChaseSpeed = 4.4f;
        public float GuardConfirmTime = 0.2f;

        public int GuardCount
        {
            get
            {
                int n = 0;
                foreach (var row in Map) foreach (char c in row) if (c == 'E') n++;
                return n;
            }
        }

        // ------------------------------------------------------------------ Os 5 níveis
        public static readonly LevelData[] All =
        {
            new LevelData
            {
                Name = "Armazém", GuardViewDistance = 8.5f, GuardChaseSpeed = 4.2f, GuardConfirmTime = 0.3f,
                Map = new[]
                {
                    "..................",
                    "..G..............G",
                    "..##..........##..",
                    "..#.....E......#..",
                    "..................",
                    "........####......",
                    "........#.........",
                    "..E.....#..G......",
                    "..................",
                    "..............##..",
                    "..##..........#...",
                    "........#.........",
                    "........#.....G...",
                    "..................",
                    "...B..........B...",
                    "..................",
                    "........P.........",
                    "..................",
                }
            },
            new LevelData
            {
                Name = "Docas", GuardViewDistance = 9f, GuardChaseSpeed = 4.4f, GuardConfirmTime = 0.25f,
                Map = new[]
                {
                    "..................",
                    ".G......#.......G.",
                    "........#.........",
                    "..####..#...####..",
                    "........E.........",
                    "..................",
                    "#####.......#####.",
                    "..................",
                    "..E.....BB.....E..",
                    "........BB........",
                    "..................",
                    ".####.......####..",
                    "........G.........",
                    "......#....#......",
                    "..#...#....#...#..",
                    "..#............#..",
                    "........P.........",
                    "..................",
                }
            },
            new LevelData
            {
                Name = "Labirinto", GuardViewDistance = 9.5f, GuardChaseSpeed = 4.6f, GuardConfirmTime = 0.2f,
                Map = new[]
                {
                    "..................",
                    ".G..#.........#.G.",
                    "....#...E.....#...",
                    ".####.......####..",
                    ".......####.......",
                    "..E.............E.",
                    "..................",
                    "###....#..#....###",
                    ".......#G.#.......",
                    ".......####.......",
                    "..B.............B.",
                    "........E.........",
                    ".####.......####..",
                    "........##........",
                    "..G.............G.",
                    "..................",
                    "..#.....P......#..",
                    "..................",
                }
            },
            new LevelData
            {
                Name = "Fábrica", GuardViewDistance = 10f, GuardChaseSpeed = 4.8f, GuardConfirmTime = 0.17f,
                Map = new[]
                {
                    "..................",
                    ".G.E..........E.G.",
                    "........##........",
                    "..##....##....##..",
                    "..##..........##..",
                    "..................",
                    "......B....B......",
                    ".####........####.",
                    "........E.........",
                    "..................",
                    "..#....####....#..",
                    "..#.E.........E#..",
                    "..#............#..",
                    "........G.........",
                    ".B..............B.",
                    "......#....#......",
                    "......#.P..#......",
                    "..................",
                }
            },
            new LevelData
            {
                Name = "Quartel", GuardViewDistance = 10.5f, GuardChaseSpeed = 5f, GuardConfirmTime = 0.15f,
                Map = new[]
                {
                    "..................",
                    ".E......G.......E.",
                    "..###.........###.",
                    "..#.....E.......#.",
                    "......######......",
                    "..................",
                    ".##.............##",
                    ".#..E.........E..#",
                    "........BB........",
                    "........BB........",
                    "..G.............G.",
                    ".####.......####..",
                    "........E.........",
                    "..................",
                    "..#...#....#...#..",
                    "..#...#....#...#..",
                    "........P.........",
                    "..................",
                }
            },
        };
    }

    /// <summary>Nível atual + progresso guardado (PlayerPrefs).</summary>
    public static class LevelManager
    {
        private const string UnlockedKey = "fsm_unlocked";
        private const string GemsKey = "fsm_gems";
        private const string DoneKey = "fsm_done_";

        public static int CurrentLevel = -1;
        public static bool SkipMenu;

        public static int Count => LevelData.All.Length;
        public static int Unlocked => Mathf.Clamp(PlayerPrefs.GetInt(UnlockedKey, 1), 1, Count);
        public static int TotalGems => PlayerPrefs.GetInt(GemsKey, 0);
        public static bool IsCompleted(int i) => PlayerPrefs.GetInt(DoneKey + i, 0) == 1;
        public static bool IsUnlocked(int i) => i < Unlocked;
        public static bool HasNext => CurrentLevel + 1 < Count;

        public static LevelData Current
        {
            get
            {
                EnsureInit();
                return LevelData.All[CurrentLevel];
            }
        }

        public static void EnsureInit()
        {
            if (CurrentLevel < 0 || CurrentLevel >= Count)
                CurrentLevel = Mathf.Clamp(Unlocked - 1, 0, Count - 1);
        }

        public static void CompleteLevel(int index, int gemsCollected)
        {
            PlayerPrefs.SetInt(DoneKey + index, 1);
            PlayerPrefs.SetInt(UnlockedKey, Mathf.Max(Unlocked, Mathf.Min(Count, index + 2)));
            PlayerPrefs.SetInt(GemsKey, TotalGems + gemsCollected);
            PlayerPrefs.Save();
        }

        public static void ResetProgress()
        {
            PlayerPrefs.DeleteKey(UnlockedKey);
            PlayerPrefs.DeleteKey(GemsKey);
            for (int i = 0; i < Count; i++) PlayerPrefs.DeleteKey(DoneKey + i);
            PlayerPrefs.Save();
            CurrentLevel = 0;
        }
    }
}
