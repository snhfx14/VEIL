using AulaFSM.Core;
using AulaFSM.Enemy;
using AulaFSM.Visuals;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.InputSystem;

namespace AulaFSM.Player
{
    /// <summary>
    /// Controlador do jogador (assassino). NÃO tem lógica de comportamento com "ifs" gigantes:
    /// lê o input, calcula o caminho e delega tudo na máquina de estados.
    ///
    /// Controlo: clicar/arrastar no chão para mover (com pathfinding à volta das caixas).
    /// Ao chegar perto de um guarda, o ataque é AUTOMÁTICO e mata com um golpe.
    ///
    /// Estados: Parado, Andar, Dash, Atacar, Ferido, Morto.
    /// </summary>
    [RequireComponent(typeof(CharacterController), typeof(Health))]
    public class PlayerController : MonoBehaviour, IStateMachineOwner
    {
        [Header("Movimento (clique do rato)")]
        public float moveSpeed = 6.5f;
        public float rotationSpeed = 900f;
        public float gravity = -25f;
        public float repathInterval = 0.08f;

        [Header("Dash (Espaço) — invulnerável e atordoa guardas")]
        public float dashSpeed = 20f;
        public float dashDuration = 0.2f;
        public float dashCooldown = 0.8f;

        [Header("Ataque automático (mata com 1 golpe)")]
        public float killRange = 1.8f;
        public float attackDuration = 0.42f;

        [Header("Dano recebido")]
        public float hurtDuration = 0.25f;
        public float knockbackSpeed = 8f;
        public float invulnerabilityAfterHit = 0.15f; // curta: o fogo contínuo dos guardas acerta quase todos os tiros

        [Header("Referências visuais")]
        public Transform model;        // corpo (roda ao morrer)
        public Transform swordPivot;   // faca (roda ao atacar)
        public Renderer bodyRenderer;

        // ------------------------------------------------------------------ Dados partilhados com os estados
        public CharacterController Controller { get; private set; }
        public Health Health { get; private set; }
        public StateMachine StateMachine { get; private set; }
        public string DisplayName => "Player";

        public Vector3 MoveInput { get; private set; }       // direção até ao próximo ponto do caminho
        public bool HasMoveInput => _hasPath;
        public bool DashPressed { get; private set; }
        public EnemyAI AttackTarget { get; private set; }    // guarda mais próximo dentro do alcance
        public bool HasTargetInRange => AttackTarget != null;
        public float LastDashTime { get; set; } = -99f;
        public Vector3 LastHitSource { get; private set; }

        /// <summary>Guarda em que o jogador clicou: persegue-o até o eliminar.</summary>
        public EnemyAI ChaseTarget { get; private set; }

        // Caminho atual (usado pelo PathVisual para desenhar o trajeto no chão)
        public Vector3[] PathCorners => _corners;
        public int PathCornerIndex => _cornerIndex;
        public Vector3 Destination => _hasPath ? _corners[_corners.Length - 1] : transform.position;

        /// <summary>Os guardas "ouvem" o jogador quando ele faz dash ou ataca.</summary>
        public bool IsMakingNoise => StateMachine.CurrentState == _dash || StateMachine.CurrentState == _attack;

        // Estados
        private PlayerIdleState _idle;
        private PlayerMoveState _move;
        private PlayerDashState _dash;
        private PlayerAttackState _attack;
        private PlayerHurtState _hurt;
        private PlayerDeadState _dead;

        // Caminho (NavMesh)
        private NavMeshPath _path;
        private Vector3[] _corners = new Vector3[0];
        private int _cornerIndex;
        private bool _hasPath;
        private float _repathTimer;

        private bool _hurtPending;
        private float _verticalVelocity;
        private Color _baseColor;
        private Renderer[] _modelRenderers;
        private bool _visible = true;

        private void Awake()
        {
            Controller = GetComponent<CharacterController>();
            Health = GetComponent<Health>();
            Health.Damaged += OnDamaged;
            if (bodyRenderer != null) _baseColor = bodyRenderer.material.color;
            _path = new NavMeshPath();

            BuildStateMachine();
        }

        /// <summary>
        /// TODO o "cérebro" do jogador está aqui: que estados existem e quando se muda entre eles.
        /// </summary>
        private void BuildStateMachine()
        {
            _idle = new PlayerIdleState(this);
            _move = new PlayerMoveState(this);
            _dash = new PlayerDashState(this);
            _attack = new PlayerAttackState(this);
            _hurt = new PlayerHurtState(this);
            _dead = new PlayerDeadState(this);

            StateMachine = new StateMachine("Player");

            // Transições globais (prioridade máxima, por esta ordem)
            StateMachine.AddAnyTransition(_dead, () => Health.IsDead, "vida chegou a 0");
            StateMachine.AddAnyTransition(_hurt, () => !Health.IsDead && ConsumeHurt(), "levou um tiro");

            // Parado
            StateMachine.AddTransition(_idle, _attack, () => HasTargetInRange, "guarda ao alcance");
            StateMachine.AddTransition(_idle, _dash, CanDash, "carregou em dash");
            StateMachine.AddTransition(_idle, _move, () => HasMoveInput, "clicou no chão");

            // Andar
            StateMachine.AddTransition(_move, _attack, () => HasTargetInRange, "guarda ao alcance");
            StateMachine.AddTransition(_move, _dash, CanDash, "carregou em dash");
            StateMachine.AddTransition(_move, _idle, () => !HasMoveInput, "chegou ao destino");

            // Dash
            StateMachine.AddTransition(_dash, _move, () => _dash.IsFinished && HasMoveInput, "dash terminou");
            StateMachine.AddTransition(_dash, _idle, () => _dash.IsFinished, "dash terminou");

            // Atacar
            StateMachine.AddTransition(_attack, _idle, () => _attack.IsFinished, "golpe terminou");

            // Ferido
            StateMachine.AddTransition(_hurt, _idle, () => _hurt.IsFinished, "recuperou");

            StateMachine.SetState(_idle);
        }

        private void Update()
        {
            bool canAct = GameManager.Instance == null || GameManager.Instance.IsPlaying;
            ReadInput(canAct);
            FollowPath();
            FindAttackTarget(canAct);
            StateMachine.Tick(Time.deltaTime);
            UpdateBlink();
        }

        // ------------------------------------------------------------------ Input (rato)

        private void ReadInput(bool canAct)
        {
            var mouse = Mouse.current;
            var kb = Keyboard.current;

            if (!canAct || Health.IsDead)
            {
                ClearPath();
                ChaseTarget = null;
                DashPressed = false;
                return;
            }

            DashPressed = (kb != null && (kb.spaceKey.wasPressedThisFrame || kb.leftShiftKey.wasPressedThisFrame)) ||
                          (mouse != null && mouse.rightButton.wasPressedThisFrame);

            // O alvo morreu (ou desapareceu): pára a perseguição
            if (ChaseTarget != null && (ChaseTarget.Health.IsDead || !ChaseTarget.isActiveAndEnabled))
            {
                ChaseTarget = null;
                ClearPath();
            }

            if (mouse == null) return;

            _repathTimer -= Time.deltaTime;
            bool clicked = mouse.leftButton.wasPressedThisFrame;

            if (clicked && TryGetMouseGroundPoint(mouse.position.ReadValue(), out var clickPoint))
            {
                // Clicou num guarda? → perseguir até o eliminar
                var enemy = FindEnemyUnderCursor(mouse.position.ReadValue(), clickPoint);
                if (enemy != null)
                {
                    ChaseTarget = enemy;
                    _repathTimer = 0f;
                    ClickMarker.Spawn(enemy.transform.position, new Color(1f, 0.25f, 0.2f, 0.9f));
                    Sfx.Play(Sfx.Click, 0.5f, 1.3f);
                }
                else
                {
                    ChaseTarget = null;
                    if (SetDestination(clickPoint))
                    {
                        ClickMarker.Spawn(_corners[_corners.Length - 1], new Color(1f, 1f, 1f, 0.85f));
                        Sfx.Play(Sfx.Click, 0.35f);
                    }
                }
            }
            else if (ChaseTarget == null && mouse.leftButton.isPressed && _repathTimer <= 0f)
            {
                // Manter carregado e arrastar: o destino segue o rato
                _repathTimer = repathInterval;
                if (TryGetMouseGroundPoint(mouse.position.ReadValue(), out var dragPoint)) SetDestination(dragPoint);
            }

            // A perseguir: recalcula o caminho porque o guarda está a mexer-se
            if (ChaseTarget != null && _repathTimer <= 0f)
            {
                _repathTimer = 0.12f;
                SetDestination(ChaseTarget.transform.position);
            }
        }

        /// <summary>Guarda debaixo do cursor (raycast ao colisor ou perto do ponto clicado no chão).</summary>
        private static EnemyAI FindEnemyUnderCursor(Vector2 screenPos, Vector3 groundPoint)
        {
            var cam = Camera.main;
            if (cam != null && Physics.Raycast(cam.ScreenPointToRay(screenPos), out var hit, 200f, ~0, QueryTriggerInteraction.Ignore))
            {
                var e = hit.collider.GetComponentInParent<EnemyAI>();
                if (e != null && !e.Health.IsDead) return e;
            }

            EnemyAI best = null;
            float bestDist = 1.4f; // tolerância para não ter de acertar em cheio
            foreach (var e in EnemyAI.All)
            {
                if (e == null || e.Health.IsDead) continue;
                Vector3 d = e.transform.position - groundPoint;
                d.y = 0f;
                if (d.magnitude < bestDist) { bestDist = d.magnitude; best = e; }
            }
            return best;
        }

        private static bool TryGetMouseGroundPoint(Vector2 screenPos, out Vector3 point)
        {
            point = Vector3.zero;
            var cam = Camera.main;
            if (cam == null) return false;
            Ray ray = cam.ScreenPointToRay(screenPos);
            var ground = new Plane(Vector3.up, Vector3.zero);
            if (!ground.Raycast(ray, out float enter)) return false;
            point = ray.GetPoint(enter);
            return true;
        }

        /// <summary>Calcula o caminho pelo NavMesh até ao ponto clicado.</summary>
        public bool SetDestination(Vector3 point)
        {
            if (!NavMesh.SamplePosition(point, out var targetHit, 3f, NavMesh.AllAreas)) return false;
            if (!NavMesh.SamplePosition(transform.position, out var selfHit, 2f, NavMesh.AllAreas)) return false;
            if (!NavMesh.CalculatePath(selfHit.position, targetHit.position, NavMesh.AllAreas, _path)) return false;
            if (_path.status == NavMeshPathStatus.PathInvalid || _path.corners.Length < 2) return false;

            _corners = _path.corners;
            _cornerIndex = 1;
            _hasPath = true;
            return true;
        }

        public void ClearPath()
        {
            _hasPath = false;
            MoveInput = Vector3.zero;
        }

        private void FollowPath()
        {
            if (!_hasPath) { MoveInput = Vector3.zero; return; }

            Vector3 target = _corners[_cornerIndex];
            Vector3 delta = target - transform.position;
            delta.y = 0f;

            if (delta.magnitude < 0.25f)
            {
                _cornerIndex++;
                if (_cornerIndex >= _corners.Length) { ClearPath(); return; }
                target = _corners[_cornerIndex];
                delta = target - transform.position;
                delta.y = 0f;
            }
            MoveInput = delta.sqrMagnitude > 0.0001f ? delta.normalized : Vector3.zero;
        }

        /// <summary>Procura o guarda vivo mais próximo dentro do alcance de ataque.</summary>
        private void FindAttackTarget(bool canAct)
        {
            AttackTarget = null;
            if (!canAct || Health.IsDead) return;
            float best = killRange;
            foreach (var enemy in EnemyAI.All)
            {
                if (enemy == null || enemy.Health.IsDead) continue;
                Vector3 d = enemy.transform.position - transform.position;
                d.y = 0f;
                float dist = d.magnitude;
                if (dist <= best) { best = dist; AttackTarget = enemy; }
            }
        }

        // ------------------------------------------------------------------ Condições

        private bool CanDash() => DashPressed && Time.time >= LastDashTime + dashCooldown;

        private bool ConsumeHurt()
        {
            if (!_hurtPending) return false;
            _hurtPending = false;
            return true;
        }

        private void OnDamaged(float amount, Vector3 source)
        {
            LastHitSource = source;
            _hurtPending = true;
        }

        // ------------------------------------------------------------------ Ações usadas pelos estados

        /// <summary>Move o CharacterController com gravidade.</summary>
        public void Move(Vector3 horizontalVelocity, float deltaTime)
        {
            if (!Controller.enabled) return;
            _verticalVelocity = Controller.isGrounded ? -2f : _verticalVelocity + gravity * deltaTime;
            Vector3 velocity = horizontalVelocity + Vector3.up * _verticalVelocity;
            Controller.Move(velocity * deltaTime);
        }

        public void FaceDirection(Vector3 direction, float deltaTime)
        {
            direction.y = 0f;
            if (direction.sqrMagnitude < 0.001f) return;
            Quaternion target = Quaternion.LookRotation(direction);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, target, rotationSpeed * deltaTime);
        }

        public void SetBodyColor(Color color)
        {
            if (bodyRenderer != null) bodyRenderer.material.color = color;
        }

        public void ResetBodyColor() => SetBodyColor(_baseColor);

        /// <summary>Pisca enquanto está invulnerável depois de levar dano.</summary>
        private void UpdateBlink()
        {
            if (model == null) return;
            if (_modelRenderers == null) _modelRenderers = model.GetComponentsInChildren<Renderer>(true);
            bool blink = Health.IsInvulnerable && !Health.IsDead && StateMachine.CurrentState != _dash;
            bool visible = !blink || Mathf.Repeat(Time.time * 12f, 1f) > 0.5f;
            if (visible == _visible) return;
            _visible = visible;
            foreach (var r in _modelRenderers) r.enabled = visible;
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position, killRange);
            if (_hasPath)
            {
                Gizmos.color = Color.cyan;
                for (int i = _cornerIndex; i < _corners.Length; i++)
                    Gizmos.DrawLine(i == _cornerIndex ? transform.position : _corners[i - 1], _corners[i]);
            }
        }
    }
}
