using System.Collections.Generic;
using AulaFSM.Core;
using AulaFSM.Player;
using AulaFSM.Visuals;
using UnityEngine;
using UnityEngine.AI;

namespace AulaFSM.Enemy
{
    /// <summary>
    /// NPC inimigo (guarda armado) controlado por uma máquina de estados.
    ///
    /// Estados: Patrulhar, Suspeito, Perseguir, Atacar (disparar), Procurar, Atordoado, Fugir, Morto.
    ///
    /// O MonoBehaviour só trata da PERCEÇÃO (ver / ouvir) e guarda dados;
    /// as DECISÕES estão nas transições e as AÇÕES estão em cada estado.
    /// </summary>
    [RequireComponent(typeof(NavMeshAgent), typeof(Health))]
    public class EnemyAI : MonoBehaviour, IStateMachineOwner
    {
        public static readonly List<EnemyAI> All = new List<EnemyAI>();

        [Header("Perceção")]
        public float viewDistance = 9f;
        [Range(10f, 360f)] public float viewAngle = 90f;
        public float hearingRadius = 6f;
        public float eyeHeight = 1.2f;

        [Header("Velocidades")]
        public float patrolSpeed = 2.2f;
        public float chaseSpeed = 4.4f;
        public float fleeSpeed = 6f;

        [Header("Combate (dispara à distância)")]
        public float attackRange = 9f;
        public float attackWindup = 0.18f;   // laser vermelho a apontar = aviso (curto!) antes do tiro
        public float attackRecover = 0.12f;  // intervalo até ao próximo tiro → ~3,3 tiros/segundo
        public float attackDamage = 25f;     // 4 tiros = morto
        public float bulletSpeed = 40f;

        [Header("Comportamento")]
        public float patrolWaitTime = 1.2f;
        public float timeToConfirmTarget = 0.2f;  // segundos a ver o jogador até ter a certeza
        public float loseTargetTime = 1.2f;       // segundos sem ver até desistir da perseguição
        public float searchDuration = 6f;
        public float stunDuration = 1.4f;
        public float scaredDuration = 3f;         // tempo a fugir depois de ver um colega morrer
        public float witnessRadius = 9f;
        public float allyAlertRadius = 10f;

        [Header("Patrulha")]
        public Vector3[] patrolPoints;

        [Header("Referências")]
        public PlayerController target;
        public Renderer bodyRenderer;
        public Transform aimLaser;   // laser vermelho (escala Z = comprimento)
        public Light flashlight;     // lanterna (luz spot) = o campo de visão

        // ------------------------------------------------------------------ Dados partilhados com os estados
        public NavMeshAgent Agent { get; private set; }
        public Health Health { get; private set; }
        public StateMachine StateMachine { get; private set; }
        public string DisplayName { get; private set; }

        public bool CanSeeTarget { get; private set; }
        public float LastTimeSeenTarget { get; private set; } = -99f;
        public float LastTimeHeardSomething { get; private set; } = -99f;
        public Vector3 LastKnownTargetPosition { get; private set; }
        public Vector3 LastHitSource { get; private set; }
        public Vector3 ScarePosition { get; private set; }
        public int PatrolIndex { get; set; }

        public bool TargetAlive => target != null && !target.Health.IsDead && (GameManager.Instance == null || GameManager.Instance.IsPlaying);
        public bool HeardSomethingRecently => Time.time - LastTimeHeardSomething < 0.25f;
        public bool LostTarget => Time.time - LastTimeSeenTarget > loseTargetTime;
        public float DistanceToTarget => target != null ? Vector3.Distance(transform.position, target.transform.position) : float.MaxValue;
        public bool TargetInAttackRange => DistanceToTarget <= attackRange;
        public bool IsScared => Time.time < _scaredUntil;

        // Estados
        private EnemyPatrolState _patrol;
        private EnemySuspiciousState _suspicious;
        private EnemyChaseState _chase;
        private EnemyAttackState _attack;
        private EnemySearchState _search;
        private EnemyStunnedState _stunned;
        private EnemyFleeState _flee;
        private EnemyDeadState _dead;

        private bool _stunPending;
        private float _scaredUntil = -99f;
        private readonly RaycastHit[] _rayHits = new RaycastHit[8];

        private void Awake()
        {
            Agent = GetComponent<NavMeshAgent>();
            Health = GetComponent<Health>();
            DisplayName = $"Guarda {All.Count + 1}";
            name = DisplayName;
        }

        private void OnEnable() => All.Add(this);
        private void OnDisable() => All.Remove(this);

        private void Start()
        {
            if (target == null) target = FindFirstObjectByType<PlayerController>();
            SetLaser(false, 0f);
            BuildStateMachine();
        }

        /// <summary>
        /// O "cérebro" do NPC: todos os estados e as regras para mudar entre eles.
        /// A ORDEM importa: a primeira transição verdadeira é a escolhida.
        /// </summary>
        private void BuildStateMachine()
        {
            _patrol = new EnemyPatrolState(this);
            _suspicious = new EnemySuspiciousState(this);
            _chase = new EnemyChaseState(this);
            _attack = new EnemyAttackState(this);
            _search = new EnemySearchState(this);
            _stunned = new EnemyStunnedState(this);
            _flee = new EnemyFleeState(this);
            _dead = new EnemyDeadState(this);

            StateMachine = new StateMachine(DisplayName);

            // --- Globais (qualquer estado) ---
            StateMachine.AddAnyTransition(_dead, () => Health.IsDead, "foi eliminado");
            StateMachine.AddAnyTransition(_stunned, () => !Health.IsDead && ConsumeStun(), "levou um encontrão (dash)");

            // --- Patrulhar ---
            StateMachine.AddTransition(_patrol, _flee, () => IsScared, "viu um colega morrer");
            StateMachine.AddTransition(_patrol, _suspicious, () => TargetAlive && (CanSeeTarget || HeardSomethingRecently), "viu/ouviu algo");

            // --- Suspeito ---
            StateMachine.AddTransition(_suspicious, _flee, () => IsScared, "viu um colega morrer");
            StateMachine.AddTransition(_suspicious, _chase, () => _suspicious.TargetConfirmed, "confirmou o jogador");
            StateMachine.AddTransition(_suspicious, _search, () => _suspicious.TimedOut, "vai investigar");
            StateMachine.AddTransition(_suspicious, _patrol, () => !TargetAlive, "alvo indisponível");

            // --- Perseguir ---
            StateMachine.AddTransition(_chase, _attack, () => TargetInAttackRange && CanSeeTarget, "jogador na mira");
            StateMachine.AddTransition(_chase, _search, () => LostTarget, "perdeu o jogador de vista");
            StateMachine.AddTransition(_chase, _patrol, () => !TargetAlive, "alvo indisponível");

            // --- Atacar (disparar) ---
            StateMachine.AddTransition(_attack, _chase, () => _attack.IsFinished && TargetAlive, "disparou");
            StateMachine.AddTransition(_attack, _patrol, () => _attack.IsFinished, "disparou");

            // --- Procurar ---
            StateMachine.AddTransition(_search, _flee, () => IsScared, "viu um colega morrer");
            StateMachine.AddTransition(_search, _chase, () => TargetAlive && CanSeeTarget, "reencontrou o jogador");
            StateMachine.AddTransition(_search, _patrol, () => _search.IsFinished || !TargetAlive, "desistiu de procurar");

            // --- Atordoado ---
            StateMachine.AddTransition(_stunned, _flee, () => _stunned.IsFinished && IsScared, "recuperou com medo");
            StateMachine.AddTransition(_stunned, _chase, () => _stunned.IsFinished && TargetAlive, "recuperou do encontrão");
            StateMachine.AddTransition(_stunned, _patrol, () => _stunned.IsFinished, "recuperou do encontrão");

            // --- Fugir ---
            StateMachine.AddTransition(_flee, _search, () => !IsScared, "acalmou-se → vai investigar");

            StateMachine.SetState(_patrol);
        }

        private void Update()
        {
            if (StateMachine == null) return;
            UpdatePerception();
            StateMachine.Tick(Time.deltaTime);
            if (bodyRenderer != null && StateMachine.CurrentState is IState s && !(s is EnemyAttackState) && !(s is EnemyStunnedState))
                bodyRenderer.material.color = Color.Lerp(bodyRenderer.material.color, s.DebugColor, Time.deltaTime * 10f);
        }

        // ------------------------------------------------------------------ Perceção

        private void UpdatePerception()
        {
            CanSeeTarget = TargetAlive && CheckVision();
            if (CanSeeTarget)
            {
                LastTimeSeenTarget = Time.time;
                LastKnownTargetPosition = target.transform.position;
            }

            // Ouvir: o jogador faz barulho quando dá dash ou ataca
            if (TargetAlive && target.IsMakingNoise && DistanceToTarget <= hearingRadius)
                Hear(target.transform.position);
        }

        private bool CheckVision()
        {
            Vector3 eye = transform.position + Vector3.up * eyeHeight;
            Vector3 targetPoint = target.transform.position + Vector3.up * 1f;
            Vector3 toTarget = targetPoint - eye;
            float distance = toTarget.magnitude;

            if (distance > viewDistance) return false;

            // Fora do cone de visão não vê (nem que esteja mesmo atrás dele → assassinato furtivo!)
            Vector3 flat = new Vector3(toTarget.x, 0f, toTarget.z);
            if (Vector3.Angle(transform.forward, flat) > viewAngle * 0.5f) return false;

            // Linha de visão: o primeiro objeto atingido (ignorando guardas) tem de ser o jogador
            return FirstHitIsTarget(eye, toTarget / distance, distance + 0.5f);
        }

        private bool FirstHitIsTarget(Vector3 origin, Vector3 dir, float maxDistance)
        {
            int count = Physics.RaycastNonAlloc(origin, dir, _rayHits, maxDistance, ~0, QueryTriggerInteraction.Ignore);
            float closest = float.MaxValue;
            Transform closestHit = null;
            for (int i = 0; i < count; i++)
            {
                var h = _rayHits[i];
                if (h.collider.GetComponentInParent<EnemyAI>() != null) continue;
                if (h.distance < closest) { closest = h.distance; closestHit = h.collider.transform; }
            }
            return closestHit != null && closestHit.GetComponentInParent<PlayerController>() == target;
        }

        /// <summary>Distância livre até ao primeiro obstáculo (para o laser).</summary>
        public float ClearDistance(Vector3 origin, Vector3 dir, float max)
        {
            int count = Physics.RaycastNonAlloc(origin, dir, _rayHits, max, ~0, QueryTriggerInteraction.Ignore);
            float best = max;
            for (int i = 0; i < count; i++)
            {
                if (_rayHits[i].collider.GetComponentInParent<EnemyAI>() != null) continue;
                if (_rayHits[i].distance < best) best = _rayHits[i].distance;
            }
            return best;
        }

        public void Hear(Vector3 position)
        {
            LastTimeHeardSomething = Time.time;
            LastKnownTargetPosition = position;
        }

        /// <summary>Quando um guarda começa a perseguir, avisa os colegas próximos.</summary>
        public void AlertAllies()
        {
            foreach (var ally in All)
            {
                if (ally == this || ally.Health.IsDead) continue;
                if (Vector3.Distance(ally.transform.position, transform.position) <= allyAlertRadius)
                    ally.Hear(LastKnownTargetPosition);
            }
        }

        /// <summary>Quando morre, os colegas próximos que estejam a ver ficam com medo.</summary>
        public void ScareWitnesses()
        {
            foreach (var ally in All)
            {
                if (ally == this || ally.Health.IsDead) continue;
                Vector3 d = transform.position - ally.transform.position;
                if (d.magnitude > ally.witnessRadius) continue;
                bool facing = Vector3.Angle(ally.transform.forward, new Vector3(d.x, 0f, d.z)) < ally.viewAngle * 0.5f;
                if (facing) ally.Scare(transform.position);
            }
        }

        public void Scare(Vector3 position)
        {
            if (Health.IsDead) return;
            _scaredUntil = Time.time + scaredDuration;
            ScarePosition = position;
            LastKnownTargetPosition = position;
        }

        // ------------------------------------------------------------------ Combate

        /// <summary>Golpe do jogador (a faca mata com um golpe).</summary>
        public void ReceiveHit(float damage, Vector3 sourcePosition)
        {
            LastHitSource = sourcePosition;
            Health.TakeDamage(damage, sourcePosition);
        }

        /// <summary>Encontrão do dash: não tira vida mas atordoa.</summary>
        public void Stun(Vector3 sourcePosition)
        {
            if (Health.IsDead) return;
            LastHitSource = sourcePosition;
            LastKnownTargetPosition = sourcePosition;
            LastTimeSeenTarget = Time.time;
            _stunPending = true;
        }

        private bool ConsumeStun()
        {
            if (!_stunPending) return false;
            _stunPending = false;
            return true;
        }

        public Vector3 MuzzlePosition => transform.position + Vector3.up * 1.17f + transform.forward * 1.1f + transform.right * 0.15f;

        public void Shoot()
        {
            if (target == null) return;
            Vector3 muzzle = MuzzlePosition;
            Vector3 aim = target.transform.position + Vector3.up * 1.1f;
            Vector3 dir = aim - muzzle;
            dir.y = 0f; // tiro horizontal
            Bullet.Spawn(muzzle, dir.normalized, bulletSpeed, attackDamage);
            Gfx.Burst(muzzle, new Color(1f, 0.85f, 0.3f), 5, 3f, 0.1f); // clarão do disparo
            Sfx.Play(Sfx.Gun, 0.55f);
            Gfx.Flash(muzzle, new Color(1f, 0.8f, 0.4f), 7f, 6f, 0.12f); // o disparo ilumina a sala
        }

        public void SetLaser(bool visible, float length)
        {
            if (aimLaser == null) return;
            aimLaser.gameObject.SetActive(visible);
            if (visible) aimLaser.localScale = new Vector3(1f, 1f, Mathf.Max(0.1f, length));
        }

        // ------------------------------------------------------------------ Utilitários para os estados

        public void FaceTowards(Vector3 position, float degreesPerSecond, float dt)
        {
            Vector3 dir = position - transform.position;
            dir.y = 0f;
            if (dir.sqrMagnitude < 0.001f) return;
            transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.LookRotation(dir), degreesPerSecond * dt);
        }

        public bool ReachedDestination =>
            Agent.enabled && !Agent.pathPending && Agent.remainingDistance <= Agent.stoppingDistance + 0.2f;

        public void MoveTo(Vector3 destination, float speed)
        {
            if (!Agent.enabled || !Agent.isOnNavMesh) return;
            Agent.isStopped = false;
            Agent.speed = speed;
            Agent.SetDestination(destination);
        }

        public void StopMoving()
        {
            if (!Agent.enabled || !Agent.isOnNavMesh) return;
            Agent.isStopped = true;
            Agent.ResetPath();
        }

        public static bool RandomPointNear(Vector3 center, float radius, out Vector3 result)
        {
            for (int i = 0; i < 10; i++)
            {
                Vector3 random = center + new Vector3(Random.Range(-radius, radius), 0f, Random.Range(-radius, radius));
                if (NavMesh.SamplePosition(random, out var hit, 2f, NavMesh.AllAreas))
                {
                    result = hit.position;
                    return true;
                }
            }
            result = center;
            return false;
        }

        // ------------------------------------------------------------------ Gizmos (cone de visão no Scene view)

        private void OnDrawGizmos()
        {
            Color c = StateMachine?.CurrentState?.DebugColor ?? Color.green;
            Gizmos.color = new Color(c.r, c.g, c.b, 0.8f);
            Vector3 eye = transform.position + Vector3.up * eyeHeight;
            Vector3 left = Quaternion.Euler(0, -viewAngle * 0.5f, 0) * transform.forward;
            Vector3 right = Quaternion.Euler(0, viewAngle * 0.5f, 0) * transform.forward;
            Gizmos.DrawLine(eye, eye + left * viewDistance);
            Gizmos.DrawLine(eye, eye + right * viewDistance);
            Gizmos.color = new Color(1f, 1f, 0f, 0.25f);
            Gizmos.DrawWireSphere(transform.position, hearingRadius);
            if (CanSeeTarget && target != null)
            {
                Gizmos.color = Color.red;
                Gizmos.DrawLine(eye, target.transform.position + Vector3.up);
            }
        }
    }
}
