using AulaFSM.Core;
using AulaFSM.Visuals;
using UnityEngine;

namespace AulaFSM.Enemy
{
    // =====================================================================
    //  PATRULHAR — percorre os pontos de patrulha, espera um pouco em cada um.
    // =====================================================================
    public class EnemyPatrolState : State<EnemyAI>
    {
        private float _waitTimer;

        public EnemyPatrolState(EnemyAI owner) : base(owner) { }
        public override string Name => "Patrulhar";
        public override Color DebugColor => new Color(0.3f, 0.85f, 0.35f);

        public override void Enter()
        {
            _waitTimer = 0f;
            GoToCurrentPoint();
        }

        public override void Tick(float dt)
        {
            if (Owner.patrolPoints == null || Owner.patrolPoints.Length == 0)
            {
                Owner.transform.Rotate(0f, 45f * dt, 0f); // sem pontos: fica a olhar à volta
                return;
            }

            if (!Owner.ReachedDestination) return;

            // Parado num ponto: olha à volta devagar
            _waitTimer += dt;
            Owner.transform.Rotate(0f, Mathf.Sin(_waitTimer * 2f) * 60f * dt, 0f);
            if (_waitTimer >= Owner.patrolWaitTime)
            {
                _waitTimer = 0f;
                Owner.PatrolIndex = (Owner.PatrolIndex + 1) % Owner.patrolPoints.Length;
                GoToCurrentPoint();
            }
        }

        private void GoToCurrentPoint()
        {
            if (Owner.patrolPoints == null || Owner.patrolPoints.Length == 0) return;
            Owner.MoveTo(Owner.patrolPoints[Owner.PatrolIndex], Owner.patrolSpeed);
        }
    }

    // =====================================================================
    //  SUSPEITO — pára e olha para onde viu/ouviu algo. Só persegue se confirmar.
    //  (dá ao jogador uma oportunidade de se esconder — típico dos jogos stealth)
    // =====================================================================
    public class EnemySuspiciousState : State<EnemyAI>
    {
        private const float MaxTime = 1.6f;
        private float _timer;
        private float _seenTime;

        public EnemySuspiciousState(EnemyAI owner) : base(owner) { }
        public override string Name => "Suspeito ?";
        public override Color DebugColor => new Color(1f, 0.9f, 0.2f);

        public bool TargetConfirmed => _seenTime >= Owner.timeToConfirmTarget;
        public bool TimedOut => _timer >= MaxTime && !Owner.CanSeeTarget;

        public override void Enter()
        {
            _timer = 0f;
            _seenTime = 0f;
            Owner.StopMoving();
            Popups.Show(Owner.transform.position + Vector3.up * 2.8f, "?", new Color(1f, 0.9f, 0.2f), 44);
            Sfx.Play(Sfx.Huh, 0.5f);
        }

        public override void Tick(float dt)
        {
            _timer += dt;
            Owner.FaceTowards(Owner.LastKnownTargetPosition, 300f, dt);
            if (Owner.CanSeeTarget)
                _seenTime += dt;
        }
    }

    // =====================================================================
    //  PERSEGUIR — corre atrás do jogador e avisa os aliados próximos.
    // =====================================================================
    public class EnemyChaseState : State<EnemyAI>
    {
        private const float RepathInterval = 0.2f;
        private float _repathTimer;

        public EnemyChaseState(EnemyAI owner) : base(owner) { }
        public override string Name => "Perseguir !";
        public override Color DebugColor => new Color(1f, 0.5f, 0.1f);

        public override void Enter()
        {
            _repathTimer = 0f;
            Owner.AlertAllies();
            Popups.Show(Owner.transform.position + Vector3.up * 2.8f, "!", new Color(1f, 0.3f, 0.2f), 52);
            Sfx.Play(Sfx.Alert, 0.6f);
        }

        public override void Tick(float dt)
        {
            _repathTimer -= dt;
            if (_repathTimer <= 0f)
            {
                _repathTimer = RepathInterval;
                Owner.MoveTo(Owner.LastKnownTargetPosition, Owner.chaseSpeed);
            }
            if (Owner.CanSeeTarget)
                Owner.FaceTowards(Owner.LastKnownTargetPosition, 360f, dt);
        }
    }

    // =====================================================================
    //  ATACAR — aponta o laser vermelho (aviso), dispara, recupera.
    // =====================================================================
    public class EnemyAttackState : State<EnemyAI>
    {
        private float _timer;
        private bool _hasShot;

        public EnemyAttackState(EnemyAI owner) : base(owner) { }
        public override string Name => "Disparar";
        public override Color DebugColor => new Color(0.95f, 0.15f, 0.15f);
        public bool IsFinished => _timer >= Owner.attackWindup + Owner.attackRecover;

        public override void Enter()
        {
            _timer = 0f;
            _hasShot = false;
            Owner.StopMoving();
        }

        public override void Tick(float dt)
        {
            _timer += dt;

            if (_timer < Owner.attackWindup)
            {
                // Aponta durante 70% da preparação, depois "tranca" a mira (dá para desviar!)
                if (_timer < Owner.attackWindup * 0.7f && Owner.target != null)
                    Owner.FaceTowards(Owner.target.transform.position, 720f, dt);

                // Laser de mira até à primeira parede
                Vector3 origin = Owner.MuzzlePosition;
                float length = Owner.ClearDistance(origin, Owner.transform.forward, Owner.attackRange + 3f);
                Owner.SetLaser(true, length);

                float blink = Mathf.PingPong(_timer * 12f, 1f);
                SetColor(Color.Lerp(DebugColor, Color.white, blink));
            }
            else
            {
                if (!_hasShot)
                {
                    _hasShot = true;
                    Owner.SetLaser(false, 0f);
                    Owner.Shoot();
                }
                SetColor(DebugColor);
            }
        }

        public override void Exit() => Owner.SetLaser(false, 0f);

        private void SetColor(Color c)
        {
            if (Owner.bodyRenderer != null) Owner.bodyRenderer.material.color = c;
        }
    }

    // =====================================================================
    //  PROCURAR — vai à última posição conhecida e procura à volta.
    // =====================================================================
    public class EnemySearchState : State<EnemyAI>
    {
        private float _timer;
        private float _lookTimer;

        public EnemySearchState(EnemyAI owner) : base(owner) { }
        public override string Name => "Procurar";
        public override Color DebugColor => new Color(0.65f, 0.35f, 1f);
        public bool IsFinished => _timer >= Owner.searchDuration;

        public override void Enter()
        {
            _timer = 0f;
            _lookTimer = 0f;
            Owner.MoveTo(Owner.LastKnownTargetPosition, Owner.patrolSpeed * 1.4f);
        }

        public override void Tick(float dt)
        {
            _timer += dt;
            if (!Owner.ReachedDestination) return;

            // Chegou: olha à volta e depois vai espreitar um ponto aleatório perto
            _lookTimer += dt;
            Owner.transform.Rotate(0f, 160f * dt, 0f);
            if (_lookTimer >= 0.9f)
            {
                _lookTimer = 0f;
                if (EnemyAI.RandomPointNear(Owner.LastKnownTargetPosition, 5f, out var point))
                    Owner.MoveTo(point, Owner.patrolSpeed * 1.4f);
            }
        }
    }

    // =====================================================================
    //  ATORDOADO — levou um encontrão (dash): é empurrado e fica tonto. Presa fácil!
    // =====================================================================
    public class EnemyStunnedState : State<EnemyAI>
    {
        private float _timer;
        private Vector3 _knockback;

        public EnemyStunnedState(EnemyAI owner) : base(owner) { }
        public override string Name => "Atordoado";
        public override Color DebugColor => new Color(0.2f, 0.9f, 1f);
        public bool IsFinished => _timer >= Owner.stunDuration;

        public override void Enter()
        {
            _timer = 0f;
            Owner.StopMoving();
            Vector3 away = Owner.transform.position - Owner.LastHitSource;
            away.y = 0f;
            _knockback = away.sqrMagnitude > 0.01f ? away.normalized * 7f : Vector3.zero;
            if (Owner.bodyRenderer != null) Owner.bodyRenderer.material.color = Color.white; // flash de impacto
            Gfx.Burst(Owner.transform.position + Vector3.up * 2f, new Color(1f, 1f, 0.4f), 6, 2.5f, 0.12f); // "estrelinhas"
            Popups.Show(Owner.transform.position + Vector3.up * 2.8f, "TONTO!", new Color(0.3f, 0.95f, 1f), 28);
            Sfx.Play(Sfx.Stab, 0.5f, 1.6f);
        }

        public override void Tick(float dt)
        {
            _timer += dt;
            float decay = 1f - Mathf.Clamp01(_timer / (Owner.stunDuration * 0.3f));
            if (Owner.Agent.enabled && decay > 0f)
                Owner.Agent.Move(_knockback * decay * dt);

            // Abana para mostrar que está tonto
            Owner.transform.Rotate(0f, Mathf.Sin(_timer * 30f) * 220f * dt, 0f);
            if (Owner.bodyRenderer != null)
                Owner.bodyRenderer.material.color = Color.Lerp(Owner.bodyRenderer.material.color, DebugColor, dt * 8f);
        }
    }

    // =====================================================================
    //  FUGIR — viu um colega ser eliminado: foge em pânico durante uns segundos.
    // =====================================================================
    public class EnemyFleeState : State<EnemyAI>
    {
        private float _repathTimer;

        public EnemyFleeState(EnemyAI owner) : base(owner) { }
        public override string Name => "Fugir !!";
        public override Color DebugColor => new Color(0.25f, 0.45f, 1f);

        public override void Enter()
        {
            _repathTimer = 0f;
            Popups.Show(Owner.transform.position + Vector3.up * 2.8f, "AAAH!", new Color(0.45f, 0.65f, 1f), 30);
            Sfx.Play(Sfx.Huh, 0.6f, 1.6f);
        }

        public override void Tick(float dt)
        {
            _repathTimer -= dt;
            if (_repathTimer > 0f && !Owner.ReachedDestination) return;
            _repathTimer = 0.7f;

            // Foge do jogador (se o vê) ou do sítio onde o colega morreu
            Vector3 threat = Owner.CanSeeTarget && Owner.target != null ? Owner.target.transform.position : Owner.ScarePosition;
            Vector3 away = Owner.transform.position - threat;
            away.y = 0f;
            if (away.sqrMagnitude < 0.01f) away = -Owner.transform.forward;

            Vector3 desired = Owner.transform.position + away.normalized * 8f;
            if (EnemyAI.RandomPointNear(desired, 3f, out var point) ||
                EnemyAI.RandomPointNear(Owner.transform.position, 8f, out point))
                Owner.MoveTo(point, Owner.fleeSpeed);
        }
    }

    // =====================================================================
    //  MORTO — estado final: cai, deixa sangue e assusta quem viu.
    // =====================================================================
    public class EnemyDeadState : State<EnemyAI>
    {
        private const float FallTime = 0.4f;
        private const float SlideTime = 0.3f;
        private const float StayTime = 5f;
        private float _timer;
        private Transform _model;
        private Quaternion _modelStartWorld;
        private Vector3 _modelStartLocalPos, _startScale, _startPos, _away, _fallAxis;

        public EnemyDeadState(EnemyAI owner) : base(owner) { }
        public override string Name => "Morto";
        public override Color DebugColor => new Color(0.35f, 0.35f, 0.35f);

        public override void Enter()
        {
            _timer = 0f;
            Owner.StopMoving();
            Owner.SetLaser(false, 0f);
            Owner.Agent.enabled = false;
            foreach (var col in Owner.GetComponentsInChildren<Collider>()) col.enabled = false;

            GameManager.Instance?.RegisterEnemyKilled();
            Owner.ScareWitnesses();

            // Direção do golpe → o corpo é projetado e cai para esse lado
            _away = Owner.transform.position - Owner.LastHitSource;
            _away.y = 0f;
            _away = _away.sqrMagnitude > 0.01f ? _away.normalized : -Owner.transform.forward;
            _fallAxis = Vector3.Cross(Vector3.up, _away);
            _startPos = Owner.transform.position;
            _startScale = Owner.transform.localScale;

            _model = Owner.transform.Find("Model");
            if (_model != null)
            {
                _modelStartWorld = _model.rotation;
                _modelStartLocalPos = _model.localPosition;

                // A arma salta da mão
                var weapon = _model.Find("WeaponPivot");
                if (weapon != null)
                {
                    weapon.SetParent(null, true);
                    weapon.gameObject.AddComponent<Debris>().Launch(_away * 3f + Vector3.up * 5f + Random.insideUnitSphere);
                }
            }
            if (Owner.bodyRenderer != null) Owner.bodyRenderer.material.color = Color.white; // flash do impacto
        }

        public override void Tick(float dt)
        {
            _timer += dt;

            // Projetado para trás (desliza e trava)
            float s = Mathf.Clamp01(_timer / SlideTime);
            Owner.transform.position = _startPos + _away * (1.6f * (1f - (1f - s) * (1f - s)));

            // Cai na direção do golpe, com um pequeno "ressalto"
            if (_model != null)
            {
                float t = Mathf.Clamp01(_timer / FallTime);
                float fall = t < 1f ? EaseInBack(t) : 1f;
                float bounce = _timer > FallTime ? Mathf.Sin(Mathf.Min(1f, (_timer - FallTime) / 0.2f) * Mathf.PI) * 6f : 0f;
                _model.rotation = Quaternion.AngleAxis(90f * fall - bounce, _fallAxis) * _modelStartWorld;
                _model.localPosition = Vector3.Lerp(_modelStartLocalPos, _modelStartLocalPos + Vector3.up * 0.3f, t);
            }
            if (Owner.bodyRenderer != null)
                Owner.bodyRenderer.material.color = Color.Lerp(Owner.bodyRenderer.material.color, DebugColor, dt * 6f);

            // Fica no chão (com o sangue) e depois afunda
            if (_timer > StayTime)
            {
                float k = 1f - Mathf.Clamp01((_timer - StayTime) / 0.6f);
                Owner.transform.localScale = _startScale * k;
                if (k <= 0f) Object.Destroy(Owner.gameObject);
            }
        }

        private static float EaseInBack(float x) => x * x * (2.2f * x - 1.2f);
    }
}
